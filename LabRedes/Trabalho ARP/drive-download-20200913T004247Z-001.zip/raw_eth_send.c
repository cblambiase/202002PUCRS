#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <linux/if_packet.h>

#define MAC_ADDR_LEN 6
#define IP_LEN 4
#define BUFFER_SIZE 42
#define MAX_DATA_SIZE 1500
#define ETHERTYPE 0x0806

int main(int argc, char *argv[])
{
	int fd, i;
	struct ifreq if_idx;
	struct ifreq if_mac;
	struct ifreq if_ip;
	struct sockaddr_ll socket_address;
	char ifname[IFNAMSIZ];
	int frame_len = 0;
	unsigned char *data;
	char buffer[BUFFER_SIZE];
	char dest_mac[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; //broadcast
	short int ethertype = htons(0x0806);
	unsigned long var, var2;

	if (argc != 2) {
		printf("Usage: %s iface\n", argv[0]);
		return 1;
	}
	strcpy(ifname, argv[1]);

	/* Cria um descritor de socket do tipo RAW */
	if ((fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) == -1) {
		perror("socket");
		exit(1);
	}

	/* Obtem o indice da interface de rede */
	memset(&if_idx, 0, sizeof (struct ifreq));
	strncpy(if_idx.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(fd, SIOCGIFINDEX, &if_idx) < 0) {
		perror("SIOCGIFINDEX");
		exit(1);
	}

	/* Obtem o endereco MAC da interface local */
	memset(&if_mac, 0, sizeof (struct ifreq));
	strncpy(if_mac.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(fd, SIOCGIFHWADDR, &if_mac) < 0) {
		perror("SIOCGIFHWADDR");
		exit(1);
	}

	/* Obtem o endereco IP da interface local */
	memset(&if_ip, 0, sizeof (struct ifreq));
	strncpy(if_ip.ifr_name, ifname, IFNAMSIZ - 1);
	if (ioctl(fd, SIOCGIFADDR, &if_ip) < 0) {
		perror("SIOCGIFADDR");
		exit(1);
	}


	/* Indice da interface de rede */
	socket_address.sll_ifindex = if_idx.ifr_ifindex;

	/* Tamanho do endereco (ETH_ALEN = 6) */
	socket_address.sll_halen = ETH_ALEN;

	/* Endereco MAC de destino */
	memcpy(socket_address.sll_addr, dest_mac, MAC_ADDR_LEN);

	/* Preenche o buffer com 0s */
	memset(buffer, 0, BUFFER_SIZE);

	/* Monta o cabecalho Ethernet */

	/* Preenche o campo de endereco MAC de destino */	
	memcpy(buffer, dest_mac, MAC_ADDR_LEN);
	frame_len += MAC_ADDR_LEN;

	/* Preenche o campo de endereco MAC de origem */
	memcpy(buffer + frame_len, if_mac.ifr_hwaddr.sa_data, MAC_ADDR_LEN);
	frame_len += MAC_ADDR_LEN;

	/* Preenche o campo EtherType */
	memcpy(buffer + frame_len, &ethertype, sizeof(ethertype));
	frame_len += sizeof(ethertype);


	//hardType
	short int hardType = htons(0x0001);
	memcpy(buffer + frame_len, &hardType, sizeof(hardType));
	frame_len += sizeof(hardType);

	//protType
	short int protType = htons(0x0800);
	memcpy(buffer + frame_len, &protType, sizeof(protType));
	frame_len += sizeof(protType);

	//hardSize / protSize
	short int hardprotSize = htons(0x0604);
	memcpy(buffer + frame_len, &hardprotSize, sizeof(hardprotSize));
	frame_len += sizeof(hardprotSize);

	//op
	short int op = htons(0x0001);
	memcpy(buffer + frame_len, &op, sizeof(op));
	frame_len += sizeof(op);

	//etherAddrMac
	memcpy(buffer + frame_len, if_mac.ifr_hwaddr.sa_data, MAC_ADDR_LEN);
	frame_len += MAC_ADDR_LEN;

	//sender ip
	struct sockaddr_in* ipaddr = (struct sockaddr_in*)&if_ip.ifr_addr;
	memcpy(buffer + frame_len, &ipaddr->sin_addr.s_addr, IP_LEN);
	frame_len += IP_LEN;

	//target mac
	frame_len += MAC_ADDR_LEN;
	
	//target ip
	var = ipaddr->sin_addr.s_addr & 0x00FFFFFF;
	for( i=0; i<256; i++){
		
		var2 = (i<<24) | var;
		memcpy(buffer + frame_len, &var2, IP_LEN);
	
		/* Envia pacote */
		if (sendto(fd, buffer, frame_len+IP_LEN, 0, (struct sockaddr *) &socket_address, sizeof (struct sockaddr_ll)) < 0) {
			perror("send");
			close(fd);
			exit(1);
		}
	}

	printf("ARP Request Enviado.\n");
	frame_len=0;

	memset(buffer, 0, BUFFER_SIZE);
	printf("Esperando Replay\n");
	while (1) {
		unsigned char mac_dst[6];
		unsigned char mac_src[6];
		unsigned char macArpDst[6];
		unsigned char macArpSrc[6];
		unsigned char ipArpDst[4];
		unsigned char ipArpSrc[4];
		short int ethertype;
		short int hardType;
		short int protType;
		short int hardprotSize;
		short int op;
		/* Recebe pacotes */
		frame_len = 0;
		if (recv(fd,(char *) &buffer, BUFFER_SIZE, 0) < 0) {
			perror("recv");
			close(fd);
			exit(1);
		}
        
		/* Copia o conteudo do cabecalho Ethernet */
		memcpy(mac_dst, buffer, sizeof(mac_dst));
		frame_len+=sizeof(mac_dst);
		memcpy(mac_src, buffer+frame_len, sizeof(mac_src));
		frame_len+=sizeof(mac_src);
		memcpy(&ethertype, buffer+frame_len, sizeof(ethertype));
		frame_len+=sizeof(ethertype);
		ethertype = ntohs(ethertype);		

		if (ethertype == ETHERTYPE) {
			
			memcpy(&hardType, buffer+frame_len, sizeof(hardType));
			frame_len+=sizeof(hardType);
			hardType = ntohs(hardType);
			memcpy(&protType, buffer+frame_len, sizeof(protType));
			frame_len+=sizeof(protType);
			protType = ntohs(protType);
			memcpy(&hardprotSize, buffer+frame_len, sizeof(hardprotSize));
			frame_len+=sizeof(hardprotSize);
			hardprotSize = ntohs(hardprotSize);
			memcpy(&op, buffer+frame_len, sizeof(op));
			frame_len+=sizeof(op);
			op = ntohs(op);

			/* Obter os endereços */		
			//sender mac
			memcpy(macArpSrc, buffer+frame_len, MAC_ADDR_LEN);
			frame_len += MAC_ADDR_LEN;

			//sender ip
			memcpy(ipArpSrc, buffer+frame_len, IP_LEN);
			frame_len += IP_LEN;

			//target mac
			memcpy(macArpDst, buffer+frame_len, MAC_ADDR_LEN);
			frame_len += MAC_ADDR_LEN;

			//target ip
			memcpy(ipArpDst, buffer+frame_len, IP_LEN);
			frame_len += IP_LEN;

			printf("MAC destino: %02x:%02x:%02x:%02x:%02x:%02x\n", 
                        mac_dst[0], mac_dst[1], mac_dst[2], mac_dst[3], mac_dst[4], mac_dst[5]);
			printf("MAC origem:  %02x:%02x:%02x:%02x:%02x:%02x\n", 
                        mac_src[0], mac_src[1], mac_src[2], mac_src[3], mac_src[4], mac_src[5]);
			printf("EtherType: 0x%04x\n", ethertype);
			printf("hardType: 0x%04x\n", hardType);
			printf("protType: 0x%04x\n", protType);
			printf("hardprotSize: 0x%04x\n", hardprotSize);
			printf("op: 0x%04x\n", op);
			
			printf("MAC sender: %02x:%02x:%02x:%02x:%02x:%02x\n", 
                        macArpSrc[0], macArpSrc[1], macArpSrc[2], macArpSrc[3], macArpSrc[4], macArpSrc[5]);
			printf("IP sender: %d.%d.%d.%d\n", 
                        ipArpSrc[0], ipArpSrc[1], ipArpSrc[2], ipArpSrc[3]);

			printf("MAC target: %02x:%02x:%02x:%02x:%02x:%02x\n", 
                        macArpDst[0], macArpDst[1], macArpDst[2], macArpDst[3], macArpDst[4], macArpDst[5]);
			printf("IP target: %d.%d.%d.%d\n", 
                        ipArpDst[0], ipArpDst[1], ipArpDst[2], ipArpDst[3]);

			printf("\n");
		}
	}

	close(fd);
	return 0;
}
